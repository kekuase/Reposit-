package com.example.passwordmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.passwordmanager.R;
import com.example.passwordmanager.PasswordAdapter;
import com.example.passwordmanager.DatabaseHelper;
import com.example.passwordmanager.Password;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView lvPasswords;
    private DatabaseHelper dbHelper;
    private List<Password> passwordList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        lvPasswords = findViewById(R.id.lvPasswords);
        Button btnAddPassword = findViewById(R.id.btnAddPassword);

        btnAddPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddPasswordActivity.class));
            }
        });

        loadPasswords();

        lvPasswords.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Password password = passwordList.get(position);
                Intent intent = new Intent(MainActivity.this, PasswordDetailActivity.class);
                intent.putExtra("password", password);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPasswords();
    }

    private void loadPasswords() {
        int userId = 1; // Временное значение, замените на реальное
        passwordList = dbHelper.getAllPasswords(userId);

        if (passwordList.isEmpty()) {
            Toast.makeText(this, "Нет сохранённых паролей", Toast.LENGTH_SHORT).show();
        }

        PasswordAdapter adapter = new PasswordAdapter(this, passwordList);
        lvPasswords.setAdapter(adapter);
    }
}