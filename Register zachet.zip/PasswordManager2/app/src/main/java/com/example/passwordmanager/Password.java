package com.example.passwordmanager;
import java.io.Serializable;

public class Password implements Serializable {
    private int id;
    private String serviceName;
    private String username;
    private String encryptedPassword;
    private String notes;

    public Password() {}

    public Password(String serviceName, String username, String encryptedPassword, String notes) {
        this.serviceName = serviceName;
        this.username = username;
        this.encryptedPassword = encryptedPassword;
        this.notes = notes;
    }

    // Геттеры
    public int getId() {
        return id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getUsername() {
        return username;
    }

    public String getEncryptedPassword() {
        return encryptedPassword;
    }

    public String getNotes() {
        return notes;
    }

    // Сеттеры
    public void setId(int id) {
        this.id = id;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEncryptedPassword(String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return serviceName;
    }
}