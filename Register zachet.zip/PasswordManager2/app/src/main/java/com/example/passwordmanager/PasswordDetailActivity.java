package com.example.passwordmanager;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.passwordmanager.R;
import com.example.passwordmanager.EncryptionHelper;
import com.example.passwordmanager.Password;

public class PasswordDetailActivity extends AppCompatActivity {
    private TextView tvServiceName, tvUsername, tvPassword, tvNotes;
    private CheckBox cbShowPassword;
    private Password password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_detail);

        password = (Password) getIntent().getSerializableExtra("password");

        tvServiceName = findViewById(R.id.tvServiceName);
        tvUsername = findViewById(R.id.tvUsername);
        tvPassword = findViewById(R.id.tvPassword);
        tvNotes = findViewById(R.id.tvNotes);
        cbShowPassword = findViewById(R.id.cbShowPassword);

        tvServiceName.setText(password.getServiceName());
        tvUsername.setText(password.getUsername());
        tvPassword.setText("********");
        tvNotes.setText(password.getNotes() != null ? password.getNotes() : "Нет заметок");

        cbShowPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    try {
                        String decryptedPassword = EncryptionHelper.decrypt(password.getEncryptedPassword());
                        tvPassword.setText(decryptedPassword);
                    } catch (Exception e) {
                        e.printStackTrace();
                        tvPassword.setText("Ошибка расшифровки");
                    }
                } else {
                    tvPassword.setText("********");
                }
            }
        });
    }
}