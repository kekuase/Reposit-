package com.example.notepaded;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView notesListView;
    private TextView selectedNoteText;
    private DatabaseHelper dbHelper;
    private List<Note> notesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        notesListView = findViewById(R.id.notesListView);
        selectedNoteText = findViewById(R.id.selectedNoteText);
        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button aboutButton = findViewById(R.id.aboutButton);
        Button exitButton = findViewById(R.id.exitButton);

        loadNotes();

        notesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Note selectedNote = notesList.get(position);
                selectedNoteText.setText(selectedNote.getTitle() + "\n" +
                        selectedNote.getDate() + "\n" +
                        selectedNote.getContent());
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NotepadActivity.class);
                startActivity(intent);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedPosition = notesListView.getCheckedItemPosition();
                if (selectedPosition != ListView.INVALID_POSITION) {
                    Note noteToDelete = notesList.get(selectedPosition);
                    dbHelper.deleteNote(noteToDelete.getId());
                    loadNotes();
                    selectedNoteText.setText("(формируется по нажатию на конкретный элемент списка)");
                    Toast.makeText(MainActivity.this, "Запись удалена", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Выберите запись для удаления", Toast.LENGTH_SHORT).show();
                }
            }
        });

        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });

        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }

    private void loadNotes() {
        notesList = dbHelper.getAllNotes();
        ArrayAdapter<Note> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_single_choice,
                notesList);
        notesListView.setAdapter(adapter);
    }
}